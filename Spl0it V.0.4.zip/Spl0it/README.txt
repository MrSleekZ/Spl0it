Hello and welcome to Spl0it Private Access!
---------------------------------------------
FAQ:
(What is Spl0it?)
* Spl0it is a program by MrSleekZ!
* Spl0it is (to be) a looping program that loops the Command Prompt while killing the spring board..

(How do I stop it?)
* There are only a few ways to stop Spl0it but there are ways netherless.
1. If you are quick enough, Press ctrl + alt+ delete, click task manager, add a new task and type,'explorer'.

2. Use an Antivirus that has a 'Safe files' feature or 'Application block' and add Spl0it.

(Is it malware?)
No, Spl0it uses a basic windows script to run the program and the payloads.

(What is the diffrence between Harmless and HARMFUL?)
The diffrence Harmless and HARMFUL is huge and important for you to know, Harmless, kills the springboard and loops the Command prompt until you restart you computer, HARMFUL on the other hand, does the same thing but everytime you boot your computer, Spl0it will run. 

(Where are the files stored?)
The files are stored anywhere you choose! 
BUT, if you ran the HARMFUL option accidently, go to the startup folder and it should be there! (Press Ctrl + R, type 'Shell:startup'.)
--------------------------------------------------
Thank you for using Spl0it and Enjoy! ;)